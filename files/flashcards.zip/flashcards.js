misty.ChangeLED(255,255,255);
misty.MoveHeadDegrees(-10, 0, 0, null, 1);
misty.SetDefaultVolume(20);
misty.Debug("Skill Starting");

misty.Set("CardIndex", 0);
misty.Set("Retrying", false);
misty.Set("Training",true);

misty.SetImageDisplaySettings("DefaultImageLayer", null, null, true);
misty.SetTextDisplaySettings("CardLayer", false, false, true, 1, 30, 400, true, "Center", "Center", "Normal", 0, 0, 0, 480, 80, true, "Courier New");
misty.DisplayText("", "CardLayer");
misty.DisplayImage("e_defaultContent.jpg");
misty.Pause(3000);
misty.Speak("Press a bump sensor to get started. If you do not know the answer, say skip.", 0, 0, null, true, null);

function registerBump(){
    misty.AddReturnProperty("Bumped", "sensorName");
    misty.AddReturnProperty("Bumped", "isContacted");
    misty.RegisterEvent("Bumped", "BumpSensor", 100, true);
}

registerBump();

misty.Set("Cards", JSON.stringify(
    {
        "Cards": [
            {"term": "Recompense", "definition": "To make amends", "status": "untested"},{"term": "Ambivalence", "definition": "The state of being uncertain", "status": "untested"},{"term": "Trepidation", "definition": "A feeling of fear or agitation", "status": "untested"},{"term": "Pinnacle", "definition": "The most successful point", "status": "untested"}
        ]
    }
));

function _Bumped(data) {
    misty.Debug("Sensor bumped");
    if (data.AdditionalResults[1]) {
        switch (data.AdditionalResults[0]) {
            case "Bump_FrontLeft":
                misty.Set("CardIndex", misty.Get("CardIndex") + 1);
                displayCard();
                break;
            case "Bump_FrontRight":
                misty.Set("CardIndex", misty.Get("CardIndex") - 1);
                displayCard();
                break;
            default:
                return;
        }
    }
}

function displayCard() {
    misty.UnregisterEvent("Bumped");
    misty.Debug("Displaying card");

    let index = misty.Get("CardIndex");
    let cardArray = JSON.parse(misty.Get("Cards"));
    let card = cardArray.Cards[misty.Get("CardIndex")];
    let learned = 0;
    let studied = 0;
    let phrases = [];

    for (let i = 0; i <cardArray.Cards.length; i++){
        misty.Debug("Card " + (i+1) + " " + cardArray.Cards[i].status);
        phrases.push(cardArray.Cards[i].term)
        if(cardArray.Cards[i].status == "learned"){
            learned++;
            studied++;
        } else if (cardArray.Cards[i].status != "untested"){
            studied++;
        }
    }
    phrases.push("skip");
    misty.Set("Phrases", JSON.stringify(phrases));
    misty.Debug("Learned cards: " + learned);
    misty.Debug("Total cards: " + cardArray.Cards.length);

    if (learned == cardArray.Cards.length){
        misty.DisplayImage("green.png");
        misty.DisplayText("All terms learned!", "CardLayer");
        misty.Speak("All terms learned!", 0, 0, null, true, null);
        misty.Pause(5000);
        misty.CancelSkill("0c08d298-de00-4d14-9485-7f7d4aa24ae6");
    }

    if (studied == cardArray.Cards.length && misty.Get("Training")){
        misty.DisplayImage("green.png");
        misty.DisplayText("Now studying incorrect terms", "CardLayer");
        misty.Speak("All terms studied. Now only studying incorrect terms.");
        misty.Pause(5000);
        misty.Set("Training", false);
    }

    if (index >= cardArray.Cards.length) {
        misty.Set("CardIndex", 0);
        displayCard();
    }
    else if (index < 0) {
        misty.Set("CardIndex", cardArray.Cards.length - 1);
        displayCard();
    }

    if(misty.Get("Training")){
        if(card.status == "learned"){
            misty.DisplayImage("green.png");
            misty.ChangeLED(0,255,0);
        } else if (card.status == "incorrect"){
            misty.DisplayImage("red.png");
            misty.ChangeLED(255,0,0);
        } else {
            misty.DisplayImage("white.jpg");
            misty.ChangeLED(255,255,255);
        }
        speakDefinition();

    } else if (!misty.Get("Training")){ //else
        if (card.status == "incorrect"){
            misty.DisplayImage("red.png");
            misty.ChangeLED(255,0,0);
            speakDefinition();
        } else {
            misty.Set("CardIndex", misty.Get("CardIndex") + 1);
            displayCard();
        }
    } 
}

function speakDefinition(){
    let index = misty.Get("CardIndex");
    let cardArray = JSON.parse(misty.Get("Cards"));
    let card = cardArray.Cards[misty.Get("CardIndex")];

    misty.DisplayText("Definition: " + card.definition, "CardLayer");
    misty.Speak(card.definition + "", 0, 0, null, true, null);
    misty.Pause(2000);
    initiateVoiceRecordEvent();
}

function initiateVoiceRecordEvent() 
{
    misty.ChangeLED(0,0,255);
    misty.AddReturnProperty("VoiceRecord", "Filename");
    misty.AddReturnProperty("VoiceRecord", "Success");
    misty.AddReturnProperty("VoiceRecord", "ErrorCode");
    misty.AddReturnProperty("VoiceRecord", "ErrorMessage");
    misty.RegisterEvent("VoiceRecord", "VoiceRecord", 100, true);
   
    misty.CaptureSpeech(false, true, 7500, 10000);
}

function _VoiceRecord(data) 
{
    misty.ChangeLED(255,0,255);
    let filename = data.AdditionalResults[0];
    let success = data.AdditionalResults[1];
    //let errorCode = data.AdditionalResults[2];
    let errorMessage = data.AdditionalResults[3];

    if (success) 
    {
        misty.Debug("Audio Recording Successful");
        misty.Set("Retrying", false);
        misty.GetAudioFile(filename, "_processAudio");
        misty.PlayAudio("s_SystemSuccess.wav", 100);
    } else {
        misty.Set("Retrying", true);
        misty.UnregisterEvent("VoiceRecord");
        misty.Debug(errorMessage);
        misty.Speak("Please try again. If you do not know the answer, say skip", 0, 0, null, true, null);
        misty.Pause(6200);
        initiateVoiceRecordEvent();
    }
}

function _processAudio(data) 
{
    misty.Debug("Audio being sent to Google Speech To Text");
    //misty.Debug(JSON.stringify(data));
    let base64 = data.Result.Base64;
    let parsed = JSON.parse(misty.Get("Phrases"));

    let arguments = {
        "config": {
          "encoding":"LINEAR16",
          "sampleRateHertz":16000,
          "languageCode":"en-US",
          "speechContexts":[{
            "phrases": parsed.phrases,
            "boost": 2
        }]
        },
        "audio": {
          "content": base64
        }
      }

    misty.Debug("Sending request");
    misty.SendExternalRequest("POST", "https://speech.googleapis.com/v1p1beta1/speech:recognize?key=INSERT_KEY_HERE", null, null, JSON.stringify(arguments), false, false, null, "application/json", "_speechToTextResponse");
}

function _speechToTextResponse(data){

    misty.Debug("Response received");
    if(data.Result.ResponseObject.Data != "{}\n"){

        let parsed = JSON.parse(data.Result.ResponseObject.Data);
        let response = parsed.results[0].alternatives[0].transcript;
        let cardArray = JSON.parse(misty.Get("Cards"));
        let correctAnswer = cardArray.Cards[misty.Get("CardIndex")].term;

        misty.Debug("Recorded response: " + response);
        misty.Debug("Correct respones: " + correctAnswer);

        if (response.includes(correctAnswer) || response.includes(correctAnswer.toLowerCase())){
            misty.Speak("Correct", 0, 0, null, true, null);
            misty.ChangeLED(0,255,0);
            misty.DisplayImage("green.png");
            misty.DisplayText("Answer: " + correctAnswer + "", "CardLayer");
            cardArray.Cards[misty.Get("CardIndex")].status = "learned";
            misty.Set("Cards", JSON.stringify(cardArray));
            misty.Debug("Done");
        } else if (response.includes("skip")) {
            misty.Speak("Skipped. The correct answer was " + correctAnswer, 0, 0, null, true, null);
            misty.ChangeLED(255,0,0);
            misty.DisplayImage("red.png");
            misty.DisplayText("Answer: " + correctAnswer + "", "CardLayer");
            cardArray.Cards[misty.Get("CardIndex")].status = "incorrect";
            misty.Set("Cards", JSON.stringify(cardArray));
            misty.Debug("Done");
        } else {
            misty.Speak("Incorrect. The correct answer is " + correctAnswer, 0, 0, null, true, null);
            misty.ChangeLED(255,0,0);
            misty.DisplayImage("red.png");
            misty.DisplayText("Answer: " + correctAnswer + "", "CardLayer");
            cardArray.Cards[misty.Get("CardIndex")].status = "incorrect";
            misty.Set("Cards", JSON.stringify(cardArray));
            misty.Debug("Done");
        }
        misty.Pause(3000);
        misty.ChangeLED(255,255,255);
        misty.DisplayImage("white.jpg");
        misty.DisplayText("Press a bump sensor to continue","CardLayer");
        misty.Speak("Press a bump sensor to continue", 0, 0, null, true, null);
        misty.UnregisterAllEvents();
        registerBump();
    } else if (!misty.Get("Retrying")){
        misty.Set("Retrying", true);
        misty.UnregisterEvent("VoiceRecord");
        misty.Debug("No voice recognized");
        misty.Speak("Please try again. If you do not know the answer, say skip", 0, 0, null, true, null);
        misty.Pause(6200);
        initiateVoiceRecordEvent();
    }
}