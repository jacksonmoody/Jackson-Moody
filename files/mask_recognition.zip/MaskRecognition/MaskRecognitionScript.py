from lobe import ImageModel
import time
import dweepy
from wireless import Wireless

wireless = Wireless()
networkName = ''
networkPassword = ''

model = ImageModel.load('/Users/Jackson/Documents/Programming/Lobe/MaskRecognitionTensorFlow')
oldMessageDate = ""

def connectNetwork():
    wireless.connect(ssid = networkName, password = networkPassword)
    time.sleep(3)
    while True:
        try:
            if wireless.current() == networkName:
                return True
            time.sleep(2)
        except:
            pass

connectNetwork()

while True:
    try:
        time.sleep(1.5)
        response = dweepy.get_latest_dweet_for('mistymaskstatus')
        newMessageDate = str(response[0]["created"]) 
        if newMessageDate != oldMessageDate:
            oldMessageDate = newMessageDate
            print("Analyzing image")
            image = model.predict_from_url('http://10.0.1.221/api/images?FileName=MaskImage.jpg&Base64=false')
            dweepy.dweet_for('mistymask', {'maskStatus': image.prediction})


    except KeyboardInterrupt:
        print ("Program Stopped")
        break

    except:
        pass
