misty.Debug("Skill Starting");
misty.MoveHead(-10, 0, 0, null, 1, null);
misty.ChangeLED(255, 255, 255);
misty.DisplayImage("e_DefaultContent.jpg");
misty.SetDefaultVolume(20);

misty.StartFaceDetection();
misty.RegisterEvent("faceDetect","FaceRecognition",7000,false);
misty.Set("oldResponse",""); 

function _faceDetect(data){
    misty.DisplayImage("e_SystemCamera.jpg");
    misty.TakePicture("MaskImage", 1600, 1200, false, true);
    misty.PlayAudio("s_SystemCameraShutter.wav");
    misty.Pause(1000);
    misty.DisplayImage("e_DefaultContent.jpg");
    misty.SendExternalRequest("POST", "https://dweet.io/dweet/for/mistymaskstatus");
    misty.RegisterTimerEvent("checkUpdate",1000,false);
}

function _checkUpdate(){
    misty.ChangeLED(0, 0, 255);
    misty.Speak("Please wait");
    misty.Pause(6500);
    misty.Debug("Sending request");
    misty.SendExternalRequest("GET", "https://dweet.io/get/latest/dweet/for/mistymask", null, null, {}, false, false, "", "application/json", "_checkUpdateResponse");
}

function _checkUpdateResponse(data) 
{
    misty.Debug("Response received");
    const response = JSON.parse(data.Result.ResponseObject.Data);
    misty.Debug("New date: " + response.with[0].created + " Old date: " + misty.Get("oldResponse"))
    if(response.with[0].created == misty.Get("oldResponse")){
        misty.Debug("No new updates");
        misty.RegisterTimerEvent("checkUpdate",3000,false);
    } else {
        misty.Debug("New update: " + response.with[0].content.status);
        if(response.with[0].content.status == "Mask"){
            misty.ChangeLED(0, 255, 0);
            misty.Speak("Thank you for wearing a mask");
        } else {
            misty.ChangeLED(255, 0, 0);
            misty.Speak("Please take a mask");
            misty.DisplayImage("rightarrow.gif");
        }
        misty.Set("oldResponse",response.with[0].created);
        misty.Pause(7000);
        misty.ChangeLED(255, 255, 255);
        misty.DisplayImage("e_DefaultContent.jpg");
        misty.RegisterEvent("faceDetect","FaceRecognition",7000,false);
    }
}