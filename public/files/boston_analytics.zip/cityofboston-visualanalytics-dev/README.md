# cityofboston-visualanalytics

## Running the project

To run **frontend**:

```bash
npm start
```

If frontend is missing packages, run:

```bash
npm install
npm start
```

To run **backend**, open a new terminal and run the following:

```bash
cd src/backend/env
source bin/activate
cd ../cityofboston_visualanalytics
python3 manage.py runserver
```