def get_endpoint(year):
    year = str(year)
    endpoints = {
        '2012': 'https://data.boston.gov/api/3/action/datastore_search?resource_id=fd5c56a7-224f-41c4-a011-969b8aee457d&limit=999999999999',
        '2013': 'https://data.boston.gov/api/3/action/datastore_search?resource_id=c2bc5615-9478-4a9b-b71c-f63f6364e409&limit=999999999999',
        '2014': 'https://data.boston.gov/api/3/action/datastore_search?resource_id=69eab395-07d3-41b8-a021-a0d314bd8046&limit=999999999999',
        '2015': 'https://data.boston.gov/api/3/action/datastore_search?resource_id=5714ab9f-52d3-4c41-b2a6-2700b41438fc&limit=999999999999',
        '2016': 'https://data.boston.gov/api/3/action/datastore_search?resource_id=ae5a15cc-8bd3-455d-8cbb-9221e07c1426&limit=999999999999',
        '2017': 'https://data.boston.gov/api/3/action/datastore_search?resource_id=01a5c35c-19e3-419e-a8b5-cb623525b96d&limit=999999999999',
        '2018': 'https://data.boston.gov/api/3/action/datastore_search?resource_id=5d8e373f-29a0-472c-b39b-9aa249e86fd5&limit=999999999999',
        '2019': 'https://data.boston.gov/api/3/action/datastore_search?resource_id=38227f56-46ed-47fe-9e1c-5d2fce52908d&limit=999999999999',
        '2020': 'https://data.boston.gov/api/3/action/datastore_search?resource_id=c093700f-d78a-49de-a8fe-508ba834ff6f&limit=999999999999',
        '2021': 'https://data.boston.gov/api/3/action/datastore_search?resource_id=32897eeb-d9ca-494f-93b1-991c50bcd6a6&limit=999999999999',
        '2022': 'https://data.boston.gov/api/3/action/datastore_search?resource_id=0a261d4e-3eec-4bac-bf72-b9a7aa77b033&limit=999999999999',
        '2023': 'https://data.boston.gov/api/3/action/datastore_search?resource_id=5ce2ff98-3313-40d2-88bd-47eae9e5a654&limit=999999999999'
        }
    if year in endpoints:
        return endpoints[year]
    else:
        return None
    
    