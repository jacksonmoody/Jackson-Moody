from django.shortcuts import render
import requests
from django.http import JsonResponse
import json
import decimal

# List of resource id's for valid years from City of Boston's API
def get_resourceid(year):
    year = str(year)
    ids = {
        '2012': 'fd5c56a7-224f-41c4-a011-969b8aee457d',
        '2013': 'c2bc5615-9478-4a9b-b71c-f63f6364e409',
        '2014': '69eab395-07d3-41b8-a021-a0d314bd8046',
        '2015': '5714ab9f-52d3-4c41-b2a6-2700b41438fc',
        '2016': 'ae5a15cc-8bd3-455d-8cbb-9221e07c1426',
        '2017': '01a5c35c-19e3-419e-a8b5-cb623525b96d',
        '2018': '5d8e373f-29a0-472c-b39b-9aa249e86fd5',
        '2019': '38227f56-46ed-47fe-9e1c-5d2fce52908d',
        '2020': 'c093700f-d78a-49de-a8fe-508ba834ff6f',
        '2021': '32897eeb-d9ca-494f-93b1-991c50bcd6a6',
        '2022': '0a261d4e-3eec-4bac-bf72-b9a7aa77b033',
        '2023': '5ce2ff98-3313-40d2-88bd-47eae9e5a654'
    }
    if year in ids:
        return ids[year]
    else:
        return None

# List of valid years from City of Boston's API
def self_get_years():
    return [2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023]

# View that returns valid years that can be accessed by City of Boston's API
def get_years(request):
    return JsonResponse({'years': self_get_years()})


# Helper function that collects responses from City of Boston API
def load_data_from_api(year, field_names=[]):
    increment = 32000
    offset = 0
    resource_id = get_resourceid(year)
    data = []

    for i in range(10000): # Timeout after this
        fields_param = '' if len(field_names) == 0 else f'&fields={",".join(field_names)}'
        link = f"https://data.boston.gov/api/3/action/datastore_search?resource_id={resource_id}&limit={increment}&offset={offset}{fields_param}"
        response = requests.get(link)
        pulled_data = json.loads(response.content)

        if not pulled_data["success"]:
            field_names = [field.lower() for field in field_names]
            continue

        data.extend(pulled_data["result"]["records"])
    
        if len(pulled_data["result"]["records"]) < increment:
            break
        
        offset += increment

    return data

# View that returns all vendors that have a transaction in a given year 
def get_vendors(request, year):
    # Fetch all data from Analyze Boston for a given year
    result = {'records': load_data_from_api(year)}
    return JsonResponse(result)

# View that returns data for a specific vendor from a specific year
def get_vendor_data(request, vendor_name, year):
    data = load_data_from_api(year)

    vendor_name = "#".join(vendor_name.split("*$HASH$*")) # IMPORTANT: Can't pass '#' in URL
    vendor_name = "/".join(vendor_name.split("*$FSLASH$*")) # IMPORTANT: Can't pass '/' in URL
    vendor_name = "\\".join(vendor_name.split("*$BSLASH$*")) # IMPORTANT: Can't pass '\\' in URL
    vendor_data = list(filter(lambda vendor: vendor["Vendor_Name" if "Vendor_Name" in vendor else "vendor_name"] == vendor_name, data))
    result = {"records": vendor_data}
    return JsonResponse(result)

# View that returns data broken down by department across all years
def get_dept_spending_across_all_years(request):
    all_data = {}

    for year in self_get_years():
        data = load_data_from_api(year, ["Dept_Name", "Monetary_Amount"])

        all_data[year] = {}

        for item in data:
            # Handle inconsistent capitalization in City of Boston's API
            deptName = "Dept_Name" if "Dept_Name" in item else "dept_name"
            amt = "Monetary_Amount" if "Monetary_Amount" in item else "monetary_amount"

            if item[deptName] not in all_data[year]:
                all_data[year][item[deptName]] = decimal.Decimal(item[amt])
            else:
                all_data[year][item[deptName]] += decimal.Decimal(item[amt])

        for key in all_data[year]:
            all_data[year][key] = float(all_data[year][key])

    return JsonResponse(all_data)

# View that returns data broken down by department for specific year
def dept_spending_for_year(request, year):
    data = load_data_from_api(year, ["Dept_Name", "Monetary_Amount"])

    all_data = {}

    for item in data:
        # Handle inconsistent capitalization in City of Boston API
        deptName = "Dept_Name" if "Dept_Name" in item else "dept_name"
        amt = "Monetary_Amount" if "Monetary_Amount" in item else "monetary_amount"

        if item[deptName] not in all_data:
            all_data[item[deptName]] = decimal.Decimal(item[amt])
        else:
            all_data[item[deptName]] += decimal.Decimal(item[amt])

    for key in all_data:
        all_data[key] = float(all_data[key])

    return JsonResponse(all_data)