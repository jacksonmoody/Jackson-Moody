import React, { useEffect, useState } from 'react'
import './css/VendorPage.css'
import NavBar from '../components/NavBar.js'
import { Card } from 'react-bootstrap'
import { ArrowBackIosNew } from '@mui/icons-material'
import { Link, useLocation } from 'react-router-dom'
import TransactionsTable from '../components/transactionsTable.js';
import Plot from 'react-plotly.js';
import { MenuItem, Select } from '@mui/material'

// Function for creating data object
function createSampleData(voucher, date, transaction, department, amount) {
  return { voucher, date, transaction, department, amount };
}

// Vendor detail card
function VendorDetailCard({ title, value }) {
  return (
    <Card id="VendorDetailCard_Container">
      <Card.Title className='HeaderText' >{title}</Card.Title>
      <div id="VendorDetailCard_Text">{value}</div>
    </Card>
  )
}

export default function VendorDetailsPage() {

  const { state } = useLocation()
  const [vendorName, setVendorName] = useState("Vendor_Name")
  const [vendorDetails, setVendorDetails] = useState([])
  const [render, setRender] = useState(false);
  const [year, setYear] = useState(2023)
  const [listOfYears, setListOfYears] = useState([2023])
  const [hasLoadedYear, setHasLoadedYear] = useState(false)
  const [pieData, setPieData] = useState([])
  const [mostFrequentlyHiredBy, setMostFrequentlyHiredBy] = useState("Loading...")

  // Clean data on page load
  useEffect(() => {
    setVendorName(state.vendorName)
    setVendorDetails(state.vendorDetails.map(vendor =>
      createSampleData(
        vendor.voucher || vendor.Voucher,
        vendor.entered || vendor.Entered,
        vendor.account_descr || vendor.Account_Descr,
        vendor.dept_name || vendor.Dept_Name,
        vendor.monetary_amount || vendor.Monetary_Amount
      )))

    const loadYears = async () => {
      await fetch('http://127.0.0.1:8000/valid_years')
        .then(async value => {
          await value.json()
            .then(jsonValue => setListOfYears(jsonValue['years']))
            .finally(() => setRender(true))
        })
        .catch(() => setRender(true))
    }

    loadYears()

    setYear(state.year)
    setHasLoadedYear(true)

  }, [state.vendorName, state.vendorDetails, state.years])

  // Update data when year changed
  useEffect(() => {
    if (!hasLoadedYear) return

    const update = async () => {
      await fetch(`http://127.0.0.1:8000/${vendorName}/${year}`)
        .then(async value => {

          await value.json()
            .then(jsonValue => {
              setVendorDetails(jsonValue["records"].map(vendor => createSampleData(
                vendor.voucher || vendor.Voucher,
                vendor.entered || vendor.Entered,
                vendor.account_descr || vendor.Account_Descr,
                vendor.dept_name || vendor.Dept_Name,
                vendor.monetary_amount || vendor.Monetary_Amount
              )))
              setRender(true)
            })
            .catch(error => console.log(error))
        })
        .catch(error => console.log(error))
    }

    update()

  }, [year])
  
  // Set most frequently hired by data
  useEffect(() => {
    let hires = {}
    vendorDetails.forEach(vendor => {
      if (vendor.department in hires) hires[vendor.department] += 1
      else hires[vendor.department] = 1
    })
    hires = Object.keys(hires).map(key => [hires[key], key])
    hires.sort((a,b) => (+b) - (+a))
    setMostFrequentlyHiredBy(hires.length ? hires[0][1] : "Loading...")

  }, [vendorDetails])

  // Create pie chart
  useEffect(() => {
    setPieData(createPieData("department", "amount"))
  }, [vendorDetails, year])

  const createPieData = (desiredKey, desiredValue) => {
    let data = {}
    vendorDetails.forEach(vendor => {
      if (vendor[desiredKey] in data) {
        data[vendor[desiredKey]] += parseFloat(vendor[desiredValue])
      } else {
        data[vendor[desiredKey]] = parseFloat(vendor[desiredValue])
      }
    })
    data = Object.keys(data).map(key => [data[key], key])
    data.sort()
    return [{
      values: data.map(elem => elem[0]),
      labels: data.map(elem => elem[1]),
      type: 'pie'
    }]
  }

  const pielayout = {
    autosize: true,
  };

  return !render ? null : (
    <div id="VendorDetailsPage_Container">
      {/* Navigation bar */}
      <NavBar position="center" />
      {/* Content */}
      <div id="VendorDetailsPage_Content">
        {/* Page back button */}
        <Link id="VendorDetailsPage_BackContent" to='/'>
          {/* Redirect back to vendor search */}
          <ArrowBackIosNew style={{ height: "18px", width: "18px" }} />
          <div>Back to vendor search</div>
        </Link>
        {/* Page title */}
        <div id="VendorDetailsPage_TopRow">
          <div className="HeaderText" id="VendorDetailsPage_Title">
            Results - {vendorName}
          </div>
          <div id="VendorDetailsPage_YearContainer">
            <Select value={year} label="Select year" onChange={event => setYear(event.target.value)}>
              {listOfYears.map((given_year, idx) =>
                <MenuItem key={idx} value={given_year}>{given_year}</MenuItem>
              )}
            </Select>
          </div>
        </div>
        {/* Details cards */}
        <div id="VendorDetailsPage_DetailCardContainer">
          {/* Cells */}
          <div id="VendorDetailsPage_DetailCardGrid">
            {[
              ["Total Spending:", "$" + vendorDetails.reduce((prev, cur) => prev + parseInt(cur.amount), 0).toLocaleString()],
              ["Total Number of Hires:", vendorDetails.length],
              ["Most Frequently Hired By:", mostFrequentlyHiredBy],
              ["Most Recent Hire Date:", vendorDetails.map(vendor => vendor.date).sort()[vendorDetails.length - 1].toLocaleString()]
            ].map((item, idx) => <VendorDetailCard key={idx} title={item[0]} value={item[1]} />)}
          </div>
          {/* Chart */}
          <div id="VendorDetailsPage_Chart">

            <Plot
              data={pieData}
              pielayout={pielayout}
              onError={err=>console.log("Plot rejected:", err)}
              debug={true}
            />
          </div>

        </div>
        {/* Transactions table */}
        <TransactionsTable data={vendorDetails} />
      </div>
    </div>
  )
}
