import React, { useEffect, useState } from 'react'
import './css/HomePage.css'
import VendorSearch from '../components/VendorSearch.js'
import { Alert, Button, Card } from 'react-bootstrap'
import NavBar from '../components/NavBar'
import Box from '@mui/material/Box';
import { LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import Grid from '@mui/material/Grid';
import { useNavigate } from 'react-router-dom'
import Plot from 'react-plotly.js';
import { MenuItem, Select, LinearProgress } from '@mui/material'

export default function HomePage() {

  const [render, setRender] = useState(false);
  const [alert, toggleAlert] = useState(false);
  const [selectedVendor, setVendor] = useState(null);
  const [vendorDetailYear, setVendorDetailYear] = useState(2023)
  const [listOfYears, setListOfYears] = useState([2023])
  const [deptSpendingData, setDeptSpendingData] = useState([])
  const [selectedSpendingYear, setSelectedSpendingYear] = useState(2023)
  const [spendingOverTimeData, setSpendingOverTimeData] = useState([])
  const [departmentBreakdownData, setDepartmentBreakdownData] = useState([])
  const [renderDepartmentBreakdown, setRenderDepartmentBreakdown] = useState(0);

  const navigate = useNavigate()

  // Handle when vendor details submit button is pressed
  const handleSubmit = async () => {

    if (selectedVendor === null) {
      toggleAlert(true)
      return
    }

    // Get records for selected vendors
    // IMPORTANT: Can't pass '#' in URL, so must replace with special key
    let mod = selectedVendor.replace(/#/g, "*$HASH$*").replace(/\//g, "*$FSLASH$*").replace(/\\/g, "*$BSLASH$*")
    await fetch(`http://127.0.0.1:8000/${mod}/${vendorDetailYear}`)
      .then(async value => {
        toggleAlert(false)

        await value.json()
          .then(jsonValue => navigate('/vendordetails', { state: { vendorName: selectedVendor, vendorDetails: jsonValue["records"], year: vendorDetailYear } }))
          .catch(_ => toggleAlert(true))
      })
      .catch(_ => toggleAlert(true))
  }

  // Load spending by department graph
  const loadSpendingByDepartment = async (year) => {
    const value = await fetch(`http://127.0.0.1:8000/dept_spending_data:${year}`);
    let jsonValue = await value.json();
    jsonValue = Object.keys(jsonValue).map(key => [jsonValue[key], key]);
    jsonValue.sort((a, b) => b[0] - a[0]);
    const limit = jsonValue.length; // Change to whatever you want - used to group categories into "Other". Setting this to `jsonValue.length` removes this functionality.
    if (jsonValue.length > limit) {
      jsonValue[limit][1] = "Other";
      for (let i = jsonValue.length - 1; i > limit; i--) {
        jsonValue[limit][0] += jsonValue[i][0];
        jsonValue.pop();
      }
    }
    const values = jsonValue.map(elem => elem[0]);
    const labels = jsonValue.map(elem => elem[1]);
    const newData = [values, labels];
    return (newData);
  }

  // Load available years
  const loadYears = async () => {
    const value = await fetch('http://127.0.0.1:8000/valid_years');
    const json = await value.json();
    setListOfYears(json['years']);
    setRender(true);
    return json['years'];
  }

  useEffect(() => {
    loadYears()
    setRender(true);
  }, [])

  // Reload spending data graph when selected spending year changes
  useEffect(() => {
    const loadDepartmentBreakdown = async () => {
      const data = await loadSpendingByDepartment(selectedSpendingYear);
      setDeptSpendingData([{
        values: data[0],
        labels: data[1],
        type: 'pie'
      }])
    }
    loadDepartmentBreakdown();
  }, [selectedSpendingYear])

  // Load spending over time graph and department breakdown graph
  useEffect(() => {
    const loadSpendingOverTimeGraph = async () => {
      await fetch('http://127.0.0.1:8000/all_dept_spending_data')
        .then(async value => {
          await value.json()
            .then(data => {
              // Spending Over Time
              const modifiedData = Object.keys(data).map(key => [key, Math.round(Object.values(data[key]).reduce((prev, cur) => prev + parseFloat(cur), 0))])

              setSpendingOverTimeData([{
                x: modifiedData.map(elem => elem[0]),
                y: modifiedData.map(elem => elem[1]),
                type: 'scatter',
                mode: 'lines+markers',
                marker: { color: 'blue' }
              }])

              // Department Breakdown
              let traces = []
              let dataKeys = Object.keys(data)
              let departments = new Set()
              dataKeys.forEach(year => Object.keys(data[year]).forEach(dept => departments.add(dept)))
              departments.forEach((dept, deptIdx) => {
                let trace = {
                  type: 'bar',
                  name: dept,
                  x: dataKeys,
                  y: new Array(dataKeys.length).fill(0)
                }
                dataKeys.forEach((year, idx) => {
                  if (dept in data[year]) trace.y[idx] += data[year][dept]
                })
                traces.push(trace)
                setRenderDepartmentBreakdown(deptIdx / departments.length * 100)
              })
              setDepartmentBreakdownData(traces)

            })
        })
    }

    loadSpendingOverTimeGraph()
  }, [])

  // Graph layout
  const layout = {
    autosize: true,
    width: 500,
  };

  // Bar graph layout
  const barlayout = {
    autosize: true,
    width: 800,
    barmode: 'stack'
  }

  return !render ? null : (
    <div id="HomePage_Container">
      <Card id="HomePage_Content">
        <NavBar />
        <div className="HeaderText" id="HomePage_CardTitle">SPENDING OVERVIEW</div>
        <Card.Body id="HomePage_CardBody">
          <div style={{ marginBottom: "48px" }}>
            The Checkbook Explorer web application provides up-to-date financial information about the City's expenditures, allowing users to interact with data on how the City is spending money. The data is updated monthly, with certain personal information omitted in order to ensure privacy. The Checkbook Explorer does not contain payroll information, which is available in the <a href="https://data.boston.gov/dataset/employee-earnings-report">Employee Earnings Report</a>, or information on independent city agencies. This dataset contains information on City expenditures that are included in the Checkbook Explorer, beginning in July 2011. It is reported by fiscal year (July-June), starting in FY12.
          </div>
          <div id="HomePage_Subtitle">Select a Year:</div>
          <div id="HomePage_DatePicker">
            <Select
              value={selectedSpendingYear}
              label="Select year"
              onChange={event => {
                setSelectedSpendingYear(event.target.value)
                setDeptSpendingData([])
              }}
              sx={{ width: 0.1 }}>
              {listOfYears.map((given_year, idx) =>
                <MenuItem key={idx} value={given_year}>{given_year}</MenuItem>
              )}
            </Select>
          </div>
        </Card.Body>
      </Card>
      <Card id="HomePage_Content">
        <Card.Body>
          <Box id="HomePage_Spending">
            <div id="HomePage_SpendingTitle">Total Spending ({selectedSpendingYear}): {deptSpendingData.length > 0 ? "$" + deptSpendingData[0].values.reduce((prev, cur) => prev + cur, 0).toLocaleString("en-US") : "Loading..."} </div>
            <Grid container justify="flex-end" alignItems="center">
              <Grid item xs={6}>
                <div id="HomePage_Subtitle">Spending By Department ({selectedSpendingYear})</div>
                <Plot data={deptSpendingData} layout={layout} />
              </Grid>
              <Grid item xs={6}>
                <div id="HomePage_Subtitle">Spending Over Time{spendingOverTimeData.length ? '' : ' (Loading...)'}</div>
                <Plot data={spendingOverTimeData} layout={layout} />
              </Grid>
              <Grid item xs={12}>
                <div id="HomePage_Subtitle">Department Breakdown</div>
                {departmentBreakdownData.length === 0 ? <>Loading...<LinearProgress variant="determinate" value={renderDepartmentBreakdown} sx={{ marginLeft: "100px", marginRight: "100px", marginTop: 3 }} /></> : <Plot data={departmentBreakdownData} layout={barlayout} />}
              </Grid>
            </Grid>
          </Box>
        </Card.Body>
      </Card>
      <Card id="HomePage_Content">
        <div className="HeaderText" id="HomePage_CardTitle">VENDOR SEARCH</div>
        <Card.Body id="HomePage_CardBody">
          <div>
            Search for a vendor below for more information about the City's expenditures and learn how the City is spending money.
          </div>
          <div id="HomePage_VendorSearch">
            <Select value={vendorDetailYear} label="Select year" onChange={event => setVendorDetailYear(event.target.value)}>
              {listOfYears.map((given_year, idx) =>
                <MenuItem key={idx} value={given_year}>{given_year}</MenuItem>
              )}
            </Select>
            <VendorSearch onChange={(_, newValue) => setVendor(newValue)} year={vendorDetailYear} />
            <Button className="HeaderText" id="HomePage_SubmitButton" onClick={handleSubmit}>
              Submit
            </Button>
          </div>
          {!alert ? null :
            <Alert key='danger' variant='danger' onClose={() => toggleAlert(false)} dismissible>Please enter a valid vendor.</Alert>
          }
        </Card.Body>
      </Card>
    </div>
  )
}
