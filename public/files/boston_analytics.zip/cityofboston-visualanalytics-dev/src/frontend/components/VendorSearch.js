import React from 'react';
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import { useEffect } from 'react';
import { useState } from 'react';



export default function VendorSearch({ onChange, year }) {
    const [vendors, setVendors] = useState([]);
    const [vendorNames, setVendorNames] = useState([]);
    
    // Update vendor search dropdown when year changed
    useEffect(() => {
        async function getVendorNames() {
            setVendorNames([])
            setVendors([])
            var response = await (await fetch(`http://127.0.0.1:8000/year:${year}`)).json()
            setVendors(response.records)
            setVendorNames([...new Set(response.records.map(item => item.vendor_name || item.Vendor_Name))].sort());
        };

        getVendorNames()
            .catch(console.error);
    }, [year]);

    return vendorNames.length === 0 ? 
    (
        <p> Loading... </p>
    )
    
    : (
        <div>

            {/* {console.log(vendors)} */}
            <Autocomplete
                disablePortal
                id="combo-box-demo"
                options={vendorNames}
                sx={{ width: 300 }}
                renderInput={(params) => <TextField {...params} label="Search for vendors" />}
                onChange={onChange}
            />
        </div>
    )
}
