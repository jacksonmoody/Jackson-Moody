import React from 'react'
import { Image } from 'react-bootstrap'
import DeptInnovTechLogo from '../assets/innovation_and_technology_logo.png'
import "./css/NavBar.css"
import { Link } from 'react-router-dom'

export default function NavBar({ position, back_route, back_title }) {

  return (
    <div id="NavBar_Bar">
      <Image id='NavBar_LogoImg' src={DeptInnovTechLogo} />
      <Link id='NavBar_TitleLink' className='HeaderText' to='/'>VISUAL ANALYTICS</Link>
    </div>
  )
}
