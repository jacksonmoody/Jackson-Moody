import React, { useEffect } from 'react';
import { useState } from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import Grid from '@mui/material/Grid';
import TableHead from '@mui/material/TableHead';
import IconButton from '@mui/material/IconButton';
import Box from '@mui/material/Box';
import TableRow from '@mui/material/TableRow';
import Collapse from '@mui/material/Collapse';
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";

export default function TransactionsTable({ data }) {


  // State for tracking if table is open
  const [open, setOpen] = useState(false);

   // State for tracking the sorting order
  const [sortOrder, setSortOrder] = useState('asc');

  // State for tracking the sorted data
  const [sortedData, setSortedData] = useState(data);

  // Perform the sorting
  const handleSort = () => {
    const sortedData = [...data].sort((a, b) => {
      if (sortOrder === 'asc') {
        return a.amount - b.amount;
      } else {
        return b.amount - a.amount;
      }
    });
    setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    setSortedData(sortedData);
  };

  
  useEffect(() => {
    setSortedData(data)
  }, [data])
  

  return (
    <>
      {/* Uncollapsable section of table */}
      <Box onClick={() => setOpen(!open)} sx={{ p: 2, border: '1px solid lightgrey', borderRadius: 2 }}>
        <Grid container alignItems="center">
          <Grid item xs={1.5}>
            <div className="HeaderText" style={{}}>Itemized List</div>
          </Grid>
          <Grid item xs={1}>
            <IconButton
              aria-label="expand row"
              size="small"
              onClick={() => setOpen(!open)}
            >
              {open ? (
                <KeyboardArrowUpIcon />
              ) : (
                <KeyboardArrowDownIcon />
              )}
            </IconButton>
          </Grid>
        </Grid>
      </Box>

      {/* Collapsable section of table */}
      <Collapse in={open}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>
                <strong>Date</strong>
              </TableCell>
              <TableCell>
                <strong>Transaction Purpose</strong>
              </TableCell>
              <TableCell>
                <strong>Hired By</strong>
              </TableCell>
              <TableCell>
                <strong>
                  Monetary Amount
                  <IconButton onClick={handleSort}>
                    {sortOrder === 'asc' ? <KeyboardArrowDownIcon /> : <KeyboardArrowUpIcon />}
                  </IconButton>
                </strong>
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
          {sortedData.map((row, idx) => (
              <TableRow key={idx}>
                <TableCell>{row.date}</TableCell>
                <TableCell>{row.transaction}</TableCell>
                <TableCell>{row.department}</TableCell>
                <TableCell>${new Intl.NumberFormat().format(row.amount)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table >
      </Collapse>
    </>
  )
}

