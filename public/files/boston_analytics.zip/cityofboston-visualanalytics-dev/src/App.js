import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import HomePage from './frontend/pages/HomePage.js';
import VendorDetailsPage from './frontend/pages/VendorDetailsPage.js';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/vendordetails" element={<VendorDetailsPage />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
