import functools

from flask import (
    Blueprint, flash, g, redirect, render_template, request, session, url_for
)
from werkzeug.security import check_password_hash, generate_password_hash
from webapp.database import db_session
from webapp.database import User

bp = Blueprint('group1', __name__, url_prefix='/')

@bp.route("/account/view", methods=["GET", "POST"])
def accountview():
    """Endpoint to view personal profile"""
    return render_template("profile.html")

@bp.route("/account/edit", methods=["GET", "POST"])
def accountedit():
    """Endpoint to edit personal profile"""
    return render_template("editprofile.html")

@bp.route("/login", methods=["GET", "POST"])
def loginendpoint():
    """Endpoint to login to the system"""
    return render_template("login.html")

@bp.route("/register", methods=["GET", "POST"])
def registerendpoint():
    """Endpoint to register a new user for the system"""
    return render_template("register.html")

@bp.route("/club/requests", methods=["GET", "POST"])
def membershiprequests():
    """Endpoint to view membership requests"""
    return render_template("membershiprequests.html")

@bp.route("/example", methods=["GET", "POST"])
def example():
    """Example endpoint for demonstration purposes"""
    return render_template("example.html")

@bp.route("/index", methods=["GET", "POST"])
def welcome():
    """Default endpoint for the system"""
    return render_template("index.html")
    