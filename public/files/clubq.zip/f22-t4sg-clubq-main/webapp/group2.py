import functools

from flask import (
    Blueprint, flash, g, redirect, render_template, request, session, url_for
)
from werkzeug.security import check_password_hash, generate_password_hash
from webapp.database import db_session
from webapp.database import User

bp = Blueprint('group2', __name__, url_prefix='/')


@bp.route("/club/create", methods=["GET", "POST"])
def create():
    """Add Club: allows club leaders to input club name, description, categories, and registration status"""
    return render_template("addclub.html")


@bp.route("/club/create/process", methods=["GET", "POST"])
def createprocess():
    """Application Process; allows club leaders to choose the application process for the club"""
    return render_template("applyprocess.html")


@bp.route("/club/create/editmembers", methods=["GET", "POST"])
def editmembers():
    """Club Membership; allows club leaders to add leaders and members, leads to addleaders and addmembers pages"""
    return render_template("clubmembership.html")
