import functools

from flask import (
    Blueprint, flash, g, redirect, render_template, request, session, url_for
)
from werkzeug.security import check_password_hash, generate_password_hash
from webapp.database import db_session
from webapp.database import User

bp = Blueprint('group3', __name__, url_prefix='/')

@bp.route("/myevents", methods=["GET", "POST"])
def events():
    """Events Endpoint: This page shows you a list of all the events you're in"""
    return render_template("myevents.html")

@bp.route("/clubview", methods=["GET", "POST"])
def clubview():
    """Clubview Endpoint: This page lets you see more information about a club"""
    return render_template("clubview.html")

@bp.route("/membershiprequest", methods=["GET", "POST"])
def membershipr():
    """Membership Request Endpoint: This page allows you to request membership to a club"""
    return render_template("membershiprequest.html")

@bp.route("/dashboard", methods=["GET", "POST"])
def dashboard():
    """Dashboard Endpoint: This page displays all of the clubs you're in or marked as interested in"""
    return render_template("dashboard.html")

@bp.route("/eventscheduling", methods=["GET", "POST"])
def eventscheduling():
    """Events Scheduling Endpoint: This page allows you to create an event."""
    return render_template("myevents.html")
